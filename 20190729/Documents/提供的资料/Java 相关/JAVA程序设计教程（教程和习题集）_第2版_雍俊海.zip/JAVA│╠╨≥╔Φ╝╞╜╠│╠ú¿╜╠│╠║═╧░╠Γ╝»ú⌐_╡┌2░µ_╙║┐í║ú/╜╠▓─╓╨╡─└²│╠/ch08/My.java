public class My{
	int value;
public static void main (String args[]) {
	My x=new My();
	if(x==null)
		System.out.println("NO Object");
		System.out.println(x.value);
		
					   }
}